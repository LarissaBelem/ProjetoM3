
import { useState, useEffect } from 'react';

import Loading from '../../components/layout/Loading';

import p1 from '../../img/p1.jpeg'
import p2 from '../../img/p2.jpeg'
import p3 from '../../img/p3.jpeg'
import p4 from '../../img/p4.jpeg'
import p5 from '../../img/p5.jpeg'
import styles from './Funcionarioos.module.css';
// importação do Components



function Funcionarioos() {
    const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
    }, 300);
  }, []);
  
    return(
      <section >
         {isLoading ? (
        <Loading />
      ) : (
        <>
<br></br>
<br></br>

<h1 className={styles.h1}> Dá onde veio a idéia?</h1>
<br></br>
<br></br>
<h6 className={styles.h6}> Perto de se mudar, Larissa não sabia mais o que fazer com tantos livros, sem contar os que ela ainda queria comprar para ler, sua melhor amiga Maria decidiu ajuda-lá a se desapegar desses livros fazendo á pensar em vende-los e comprar novos, mas isso ainda a deixaria no prejuízo e sem contar na preocupação de não saber se a outra pessoa iria cuidar deles tanto quanto ela, era difícil a comunicação com um comprador desses sites comuns. Então, as duas juntamente com seu grupo de amigos (Rute,Karine e Daniel) em comum decidiram contruir uma plataforma aonde você tem contato direto com quem está comprando e também pode comprar novos livros que desejar ler, tudo em ujm só lugar e com uma comunicação limpa e direta!</h6>
<br></br>
<br></br>
<br></br>
<br></br>
        
        <h2 className={styles.h1}> Fundadores - Só Mais Um Livro</h2>
        
<div class="container text-center mt-5">
  <div class="row">
    <div class="col ">
    <div class="card text-bg-dark" >
  <img src={p1}  class="card-img-top" alt="..."/>
  <div class="card-body cd">
    <h5 className={styles.cardtitle}>Daniel Víctor</h5>
    <p class="card-text">Programador</p>
    <a className={styles.btn} href="" target="_blank">Mais informações</a>
  
  </div>
</div>
  
    </div>
    <div class="col" >
    <div class="card text-bg-dark" >
  <img src={p2} class="card-img-top" alt="..."/>
  <div class="card-body cd">
    <h5 className={styles.cardtitle}>Larissa Belem</h5>
    <p class="card-text">Criadora</p>
    <a className={styles.btn} href="https://www.linkedin.com/in/larissa-belem-%F0%9F%8F%B3%EF%B8%8F%E2%80%8D%F0%9F%8C%88-53a999190/" target="_blank">Mais informações</a>

  </div>
</div>
    </div>
    <div class="col" >
    <div class="card text-bg-dark" >
  <img src={p3} class="card-img-top" alt="..."/>
  <div class="card-body cd" className={styles.cd}>
    <h5 className={styles.cardtitle}>Maria Do Carmo</h5>
    <p class="card-text" className="cd">Co-Criadora</p>
    <a className={styles.btn} href="https://www.instagram.com/soumaylima/" target="_blank">Mais informações</a>
    
  </div>
</div>
    </div>
   
    <div class="col" >
    <div class="card text-bg-dark" >
  <img src={p4} class="card-img-top" alt="..."/>
  <div class="card-body cd">
    <h5 className={styles.cardtitle}>Karine Melo</h5>
    <p class="card-text" className="cd">Programadora</p>
    <a className={styles.btn} href="" target="_blank">Mais informações</a>
    
    
  </div>
</div>
    </div>

    <div class="col" >
    <div class="card text-bg-dark" >
  <img src={p5} class="card-img-top" alt="..."/>
  <div class="card-body cd">
    <h5 className={styles.cardtitle}>Rute Ferreira</h5>
    <p class="card-text" className="cd">Marketing</p>
    <a className={styles.btn} href="https://www.linkedin.com/in/rute-silveira-a44aa7252/" target="_blank">Mais informações</a>
    
    
  </div>
</div>
    </div>
   
  </div>
</div>

<br></br>
<br></br>
<br></br>

  </>
)}
</section>

    )
}
export default Funcionarioos