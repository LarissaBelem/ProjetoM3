// importação do React
import { useState, useEffect } from 'react';

// importação do Components
import Loading from '../../components/layout/Loading';

// importação do CSS
import styles from './Home.module.css';

//importação da imagem
import savings from '../../img/savings.svg';
import LinkButton from '../layout/LinkButton';

//imagens
import bn2 from '../../img/bn2.jpg';
import bn1 from '../../img/bn1.jpg';
import crep from '../../img/crep.jpg';
import cd1 from '../../img/cd1.jpg';
import cd2 from '../../img/cd2.jpeg';
import cd5 from '../../img/cd5.jpeg';
/*import cp1 from '../../img/cp1.jpg';*/
import f1 from '../../img/f1.png';
import f2 from '../../img/f2.png';
import f3 from '../../img/f3.png';

function Home() {
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
    }, 300);
  }, []);

  return (
    <section class="container w-75 text-center" className={styles.homeContainer}>
      {isLoading ? (
        <Loading />
      ) : (
        <>
          <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="true">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src={bn2} class="d-block w-100" alt="..." />
              </div>
              <div class="carousel-item">
                <img src={bn1} class="d-block w-100" alt="..." />
              </div>
              <div class="carousel-item">
                <img src={crep} class="d-block w-100" alt="..." />
              </div>
            </div>
            <button
              class="carousel-control-prev"
              type="button"
              data-bs-target="#carouselExampleIndicators"
              data-bs-slide="prev"
            >
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button
              class="carousel-control-next"
              type="button"
              data-bs-target="#carouselExampleIndicators"
              data-bs-slide="next"
            >
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Next</span>
            </button>
          </div>


          <h1 className={styles.titulof}>Veja mais dos nossos livros</h1>
          <br></br>
    
    <LinkButton to="/dashimoveis" text="Ver mais" />
    <br></br>
  <br></br>
  <br></br>
    <h2 className={styles.titulof}> Só Mais Um Livro </h2>
    <br></br>
    <div className={styles.h3}>
     <h3>Este projeto foi pensado por alguém que ama livros, para você que também ama livros e que precisa de um dinheiro extra. Aqui você vende aquele livro que já leu e compra um de seu interesse por um preço menor, e acessível, pode também vender sua própria história se assim desejar. Um ambiente completo onde você entra em contato com o próprio vendedor e combina o melhor para os dois lados. Troca e venda em apenas um site, aqui ninguém sai perdendo, e assim você contribui com o consumo  sustentável! Em vez de comprar vários livros que irão ficar parados na sua estante, você pode trocar/vender aqueles que não irá ler novamente por outro que você está desejando muito!</h3> </div>
     <br></br>
     <br></br>
     

    <LinkButton to="/funcionarioos" text="Equipe" />

    <br></br>
    <br></br>
    

     <h2 className={styles.titulof}>Nossos queridinhos</h2>

    <div class="text-center mt-5 ">
      <div class="row justify-content-around">
        <div class="col-12 col-sm-6 col-lg-4">
          <img className={styles.card} src={cd1} />
          <p>A Seleção</p>
        </div>

        <div class="col-12 col-sm-6 col-lg-4">
          <img className={styles.card} src={cd2} />
          <p>O Senhor dos Aneis</p>
        </div>
        <div class="col-12 col-sm-6 col-lg-4">
          <img className={styles.card} src={cd5} />
          <p>O Morro Dos Ventos Uivantes</p>
        </div>
        
      </div>
    </div>
    
    <div class="container text-center mt-5">
      <div class="row">
        <div class="col">
          <img className={styles.f1} src={f1} />
          <p>Entregue direto na sua casa.</p>
        </div>
        <div class="col">
          <img className={styles.f1} src={f2} />
          <p>Venda suas próprias obras.</p>
        </div>
        <div class="col">
          <img className={styles.f1} src={f3} />

          <p>Livros perfeitos para qualquer momento.</p>
        </div>
      </div>
    </div>
  </>
      )}
    </section>
  );
}

export default Home;
