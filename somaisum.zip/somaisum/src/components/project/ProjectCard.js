import { Link } from "react-router-dom"
import styles from './ProjectCard.module.css'
import { BsPencil, BsFillTrashFill } from 'react-icons/bs' //Assim se puxam os ícones

function ProjectCard({id, name, filme, horario, idioma, duracao, handleRemove}){
    const remove = (e) => {
      e.preventDefault()
      handleRemove(id)
    }

    return (
        <div className={styles.project_card}>
         <h4> {name} </h4>
         <p className={styles.category_text}><strong>Livro: &nbsp;</strong> {filme} </p>
         <p className={styles.category_text}><strong>Telefone: &nbsp;</strong> {duracao} </p>
         <p className={styles.category_text}><strong>Preço: &nbsp;</strong> R${horario} </p>
         <p className={styles.category_text}><strong>Sinopse: &nbsp;</strong> {idioma} </p>
         <div className={styles.project_card_actions}>
            <Link to={`/imovel/${id}`}>
                <BsPencil /> Editar
            </Link>
            <button onClick={remove}>
                <BsFillTrashFill /> Excluir
            </button>
            
         </div>
       </div>
    )
}

export default ProjectCard;