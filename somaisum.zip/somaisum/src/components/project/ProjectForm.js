import{useState, useEffect} from 'react'

import Input from '../form/Input'
import Select from '../form/Select'
import SubmitButton from '../form/SubmitButton';

import styles from './ProjectForm.module.css'

function ProjectForm({handleSubmit, btnText, imovelData}) { // Talvez mudar projectData para imovelData
  const [imovel, setImovel] = useState(imovelData || {})
  const optionsForm = [
    {
      id: 1,
      value: 'Romance',
      label: 'Romance'
    },
    {
      id: 2,
      value: 'Drama',
      label: 'Drama'
    },
    {
      id: 3,
      value: 'Suspense',
      label: 'Suspense'
    },
    {
      id: 4,
      value: 'Fantasia',
      label: 'Fantasia'
    },
    {
      id: 5,
      value: 'Não ficção',
      label: 'Não Ficção'
    },
    {
      id: 6,
      value: 'Poesia',
      label: 'Poesia'
    },
  ]

  useEffect(() => {
    fetch('http://localhost:5000/imovel', {
    method:"GET",
    headers: {
      'Content-type': 'application/json'
    }
  })}, [])

  const submit = (e) => {
    e.preventDefault()
    handleSubmit(imovel)  // Quando duplicar alterar aqui p/ vendedores ou compradores
  }

  function handleChange(e) {
    setImovel({...imovel, [e.target.name]: e.target.value}) // Quando duplicar alterar imovel p/ vendedores ou compradores
   
  }

  function handleCategory(e) {
    setImovel({
      ...imovel, // Quando duplicar alterar imovel p/ vendedores ou compradores
      category: {
        id: e.target.value,
        tipo:e.target.options[e.target.selectedIndex].text,
      },
    })
    
  }

  return ( // incluído tbm o onSubmit (precisa duplicar nos outros forms)
    <form onSubmit={submit} className={styles.form}> 

      <Input 
        type='text'
        text='Título'
        name='filme'
        placeholder='Insira o título do Livro'
        handleOnChange={handleChange}
        value={imovel.filme ? imovel.filme : ''}
      />
      <Input 
        type='text'
        text='Telefone'
        name='duracao'
        placeholder='Insira o seu número para contato'
        handleOnChange={handleChange}
        value={imovel.duracao ? imovel.duracao: ''}
      />
      <Input 
        type='text'
        text='Preço'
        name='horario'
        placeholder='Insira o Preço Que Deseja Pelo Aluguel'
        handleOnChange={handleChange}
        value={imovel.horario ? imovel.horario : ''}
      />

<Input
        type='text'
        text='Sinopse'
        name='idioma'
        placeholder='Insira a sinopse'
        handleOnChange={handleChange}
        value={imovel.idioma ? imovel.idioma : ''}
      />
    
      <Select 
      name='category_id' 
      text='Selecione o Gênero do Seu Livro '
      options={optionsForm}
      handleOnChange={handleCategory}
      value={imovel.category ? imovel.category.id : ''}
       />
      <SubmitButton text={btnText} />
    </form>
  );
}

export default ProjectForm;
