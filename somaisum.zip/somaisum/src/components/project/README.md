# Project

Aqui está o modelo de formulário, que será utilizado nas páginas.

- Aos 14:32min do vídeo: https://www.youtube.com/watch?v=dZtuJ2Ns7q8&list=PLnDvRpP8BneyVA0SZ2okm-QBojomniQVO&index=23&t=2s&ab_channel=MatheusBattisti-HoradeCodar . O professor mostra como ele será usado em cada página.

